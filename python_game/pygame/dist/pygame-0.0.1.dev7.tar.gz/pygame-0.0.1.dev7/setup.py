from setuptools import setup
import pbr


setup(setup_requires=['pbr'], pbr=True)
