from setuptools.config import read_configuration
from setuptools import setup


conf_dir = read_configuration('setup.cfg')

setup()