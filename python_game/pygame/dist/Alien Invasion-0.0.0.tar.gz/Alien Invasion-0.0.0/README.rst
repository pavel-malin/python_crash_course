
A game of alien invasion, an old game. Rewritten in python 3 using the
pygame library for consciousness of games in this language.

The game is launched by alien_invasion.py.
This work was done so that there was an understanding of the work of this
library for the implementation of games, an understanding of all the pros
and cons of developing games in this library for this language.

The game is not a finished product. This is for educational purposes only.

All files have documentation and code comments.
If there is any other suggestion for consideration or explanation on the
example of something to show you the work, then contact us and see what and
how to find out options, I think we will be able to figure it out.


All code tests will be done soon.
